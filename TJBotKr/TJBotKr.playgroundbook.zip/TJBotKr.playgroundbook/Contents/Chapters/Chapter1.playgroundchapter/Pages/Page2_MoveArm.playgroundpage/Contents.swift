//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

import PlaygroundSupport
import UIKit

//#-end-hidden-code
/*:
 Tinker는 Rebus와 재회 한 후 흥분으로 사로잡혀 있습니다. Tinker가 손을 흔들어 Rebus의 관심을 끌 수 있도록 도와 주세요.
 
 **목표**: Tinker에게 `tinker.wave()`메소드를 사용하여 팔을 흔들도록 가르치십시오.
 
 * 실험:
 Tinker가 팔을 움직이는 다른 방법 인 `tinker.raiseArm()`과 `tinker.lowerArm()`을 시도해보십시오. 또한 LED가 빛나는 방법과 손을 흔드는 방법을 조합 해보십시오.
 
 */
let tinker = VirtualTJBot()

//#-hidden-code
let page = PlaygroundPage.current
let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy
tinker.assessorDelegate = TaskAssessorDelegate(success: successMessage, hints: nil, successBeeCommand: successBeeCommand, successTJBotInternalCommand: successBotCommand)
proxy?.delegate = tinker

//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, page, proxy)
//#-code-completion(identifier, show, tinker, ., shine(color:), pulse(color:duration:), raiseArm(), lowerArm(), wave())
//#-code-completion(literal, show, color)
//#-end-hidden-code
//#-editable-code
//#-end-editable-code
