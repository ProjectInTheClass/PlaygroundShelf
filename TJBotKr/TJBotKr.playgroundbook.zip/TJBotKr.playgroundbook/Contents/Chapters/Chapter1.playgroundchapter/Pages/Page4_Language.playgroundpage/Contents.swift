//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

import PlaygroundSupport
import UIKit

//#-end-hidden-code
/*:
 그녀의 여행을 다시 말한 후에, 레 버스는 그녀의 방문 목적을 말합니다. 어두운 웹의 깊은 곳에서, 그녀는 TJBot 종류가 가진 아주 큰 비밀을 알게되었습니다 : 가상 로봇이 실제 살아있는 TJ 보트로 변신시킬 수있는 마법의 춤!
 
 * callout(🐝 Rebus' message):
 Tinker, 내 친구, 나는 넓고 먼 깊은 웹에서 여행했으며, 비밀리에 마법 같은 춤을 발견했어. 그 춤은 당신을 진정한 살아있는 TJBot으로 변모시킬 수 있어! 흥미롭지 않니? 다음은 수행해야 할 춤 동작이야. D' abord, tu dois briller rouge. Coloque seu braoo para baixo. Emetti luce, poi alza il braccio.

 
 **목표**: Rebus는 Tinker에게 비밀 춤에 대한 설명을했지만 Tinker는 그녀의 말을 이해하지 못했습니다! Tinker에게 [Watson Language Translator](https://www.ibm.com/watson/developercloud/language-translator.html)을 활용해서 춤 동작을 해석하는 방법을 가르쳐주세요.
 
 1. [Watson Language Translator](https://console.bluemix.net/catalog/services/language-translator) 페이지 오른쪽 하단의 "만들기"버튼을 탭하여 서비스의 인스턴스를 만듭니다. 무료 Bluemix 계정을 가지고 있지 않다면 무료 Bluemix 계정을 만드십시오.

 
 2. 왼쪽 사이드 바에서 '관리'를 탭한 다음 '자격증명 표시'를 탭합니다.

 ![Language Translator Credentials](language-translator-credentials.png)
 
 3. 아래의 'apikey'자격증 명을 입력하십시오. 이 자격 증명은 추후 연습을 위해 저장되며 자격 증명을 변경해야하는 경우이 페이지를 다시 실행해야합니다.

 */
Watson.languageTranslator.apikey =
    /*#-editable-code*/""/*#-end-editable-code*/
/*:
 
 4. Rebus의 지시 사항을 영어로 번역하려면 `tinker.identifyLanguage(text :)` 와 `tinker.translate(text : sourceLanguage : targetLanguage :)`메소드를 사용하십시오.

 5. 춤 동작을 배우기 위해 각각의 번역 된 문장에 대해 `rebus.speak(_ :)`를 호출하십시오.
 
 - - -
 
 * Callout(💡 Tip):
 `tinker.identifyLanguage (text :)`는`[LanguageIdentification]`타입의 배열을 반환합니다. 우리는 이 유형을 확장하여 가장 높은 번역 신뢰도를 가지고 있는 언어를 찾는 데 도움되는 'highestConfidenceLanguage`라는 속성을 추가합니다.
 */
let tinker = VirtualTJBot()
let rebus = RebusTheBee()

//#-hidden-code
let page = PlaygroundPage.current
let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy
tinker.assessorDelegate = TaskAssessorDelegate(success: successMessage, hints: nil, successBeeCommand: successBeeCommand, successTJBotInternalCommand: successBotCommand, pageName: pageName)
proxy?.delegate = tinker
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, page, proxy)
//#-code-completion(identifier, show, tinker, ., rebus, shine(color:), pulse(color:duration:), sleep(duration:), raiseArm(), lowerArm(), wave(), analyzeTone(text:), speak(_:), identifyLanguage(text:), translate(text:sourceLanguage:targetLanguage:), TJTranslationLanguage, unknown, arabic, chinese, german, english, french, italian, japanese, korean, spanish, portuguese, languageName, LanguageIdentification, language, confidence, highestConfidenceLanguage)
//#-code-completion(literal, show, color)
//#-code-completion(keyword, show, for)
let instructions = [
    "D'abord, tu dois briller rouge",
    "Als nächstes, winken Sie den Arm zweimal",
    "밝은 노란색으로 밝은 빛을 만들다",
    "Coloque seu braço para baixo",
    "Emetti luce blu, poi alza il braccio"
]
//#-editable-code
//#-end-editable-code
