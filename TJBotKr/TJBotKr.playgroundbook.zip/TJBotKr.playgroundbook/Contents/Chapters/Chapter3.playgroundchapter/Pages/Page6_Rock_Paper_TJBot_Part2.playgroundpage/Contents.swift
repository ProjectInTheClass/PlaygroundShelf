//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

import PlaygroundSupport
import UIKit

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.assessmentStatus = .pass(message: nil)
//#-end-hidden-code
/*:
 * Callout(🤖 TJBot Hardware):
 이 연습을 끝내려면 TJBot에 LED, 스피커, 서보 및 마이크가 있는지 확인하십시오.
 
조금 더 해봅시다. 이전 연습에서 코드에서 직접 이동을 입력하여 TJBot으로 가위, 바위, 보를 수행했습니다. 이 연습에서는 TJBot에게 말함으로써 움직이십시오. 걱정하지 마세요, 그는 속일 수 없습니다!
 
 ** Goal ** :`tj.listen()`을 사용하여 게임을 향상시켜 TJBot이 당신의 움직임을들을 수 있도록하십시오. TJBot에게 "바위", "종이"또는 "가위"라고 말하여 그에게 당신의 움직임을 이야기하십시오.
 
 이 연습에서는 TJBot이 다음 작업을 수행해야합니다.
 1. Rock Paper Scissors의 새로운 게임이 곧 시작될 것이라고 발표하십시오.
 2. 가위 바위 가위의 규칙을 설명하십시오.
 3. move를 요청하십시오. 예를 들어, TJBot은 "당신의 move는 무엇입니까?"라고 말할 것입니다.
 
 * Callout (💡 팁) :
 TJBot이 당신의 움직임을 이해하지 못한다면, 그는 당신이 이해하지 못했고 당신의 움직임에 대해 다시 한번 요청하도록 해야 합니다.
 
 4. 팔을 흔들고 듣는 순간 움직임을 알려줍니다. 예를 들어, TJBot은 "좋아요, 움직였습니다. 가위를 선택했습니다."라고 말할 수 있습니다.
 5. 팔을 내리고 그의 움직임을 말하세요. 예를 들어, TJBot은 "나는 바위를 선택했다"고 말할 것입니다.
 6. 승자를 결정하십시오. 이기면 TJBot이 당신을 축하해 주어야합니다! TJBot이 이기면 승리 춤을 추어야합니다. 동점 일 경우 TJBot은 다시 게임을해야합니다.
 7. 게임이 끝나면`endGame()`메서드를 호출하여 게임을 끝내십시오. 이 방법은 TJBot에게 마이크 청취를 중단하고 Playgrounds의 실행을 끝내도록 지시합니다.
 
 */
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, page, proxy)
//#-code-completion(identifier, show, tj, ., shine(color:), pulse(color:duration:), raiseArm(), lowerArm(), wave(), sleep(duration:), speak(_:), see(), read(), components(separatedBy:), contains(_:), arc4random_uniform(_:), UInt32, Int)
//#-code-completion(literal, show, color)
let tj = PhysicalTJBot()

//#-hidden-code
func endGame() {
    PlaygroundPage.current.finishExecution()
}
//#-end-hidden-code
//#-editable-code
//#-copy-destination("Page5_Rock_Paper_TJBot_Part_1", id1)
enum Move: String {
    case rock
    case paper
    case scissors
}

enum GameResult: String {
    case win
    case tie
    case lose
}

func randomMove() -> Move {
    let randomNumber = Int(arc4random_uniform(UInt32(3)))
    switch randomNumber {
    case 0:
        return .rock
    case 1:
        return .paper
    case 2:
        return .scissors
    default:
        return .rock
    }
}

func gameResult(tjbot move: Move, beats other: Move) -> GameResult {
    switch move {
    case .rock:
        switch other {
        case .rock: return .tie
        case .paper: return .lose
        case .scissors: return .win
        }
    case .paper:
        switch other {
        case .rock: return .win
        case .paper: return .tie
        case .scissors: return .lose
        }
    case .scissors:
        switch other {
        case .rock: return .lose
        case .paper: return .win
        case .scissors: return .tie
        }
    }
}

let intro = "Hello! Let's play a game of rock paper scissors. The rules are as follows. Rock breaks scissors, scissors cuts paper, and paper covers rock. Ready? Let's go."

let tjbotMove: Move = randomMove()

//#-end-copy-destination
//#-end-editable-code

//: [Next page: Conversing with TJBot](@next)
