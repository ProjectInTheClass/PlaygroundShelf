//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

import PlaygroundSupport
import UIKit

PlaygroundPage.current.assessmentStatus = .pass(message: nil)
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
/*:
 이 TJBot 여행을 우리 함께 해주셔서 감사합니다!
 
 이제 TJBot이 자신이 할 수있는 것을 보여 주었고, 그는 당신과 함께 모험을 즐기고 싶습니다!
 
 * 실험 :
 전체 TJBot API를 사용하여 TJBot에 대한 나만의 사용법을 쓸 수 있습니다. 유일한 규칙은 창의력이 있고 즐겁게 하는 것이고, 유일한 한계는 당신의 상상력입니다! 🚀
 
 #tjbot 해시 태그를 사용하여 TJBot과 경험을 공유하는 것을 잊지 마십시오! 우리는 TJBot과 함께 하는 여러분의 모험을 기다립니다.  🤖❤️
*/
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, page, proxy)
//#-code-completion(identifier, show, tj, ., shine(color:), pulse(color:duration:), raiseArm(), lowerArm(), wave(), sleep(duration:), speak(_:), listen(_:), see(), read(), converse(workspaceId:message:), analyzeTone(text:), identifyLanguage(text:), translate(text:sourceLanguage:targetLanguage:), components(separatedBy:), contains(_:), lowercased(), sorted(), description, ToneResponse, error, emotion, language, social, anger, fear, joy, sadness, analytical, confident, tentative, openness, conscientiousness, extraversion, agreeableness, emotionalRange, TJTranslationLanguage, unknown, arabic, chinese, german, english, french, italian, japanese, korean, spanish, portuguese, languageName, LanguageIdentification, language, confidence, highestConfidenceLanguage, VisionResponse, objects, VisualObjectIdentification, name, confidence, highestConfidenceObject, ConversationResponse, text, arc4random_uniform(_:), UInt32, Int)
//#-code-completion(literal, show, color)
let tj = PhysicalTJBot()

//#-editable-code
//#-end-editable-code
