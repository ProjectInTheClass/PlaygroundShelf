//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

//#-end-hidden-code
/*:
 TJBot의 소프트웨어를 설치하는 것은 쉽습니다! 우리는 여러분이 TJBot을 설치하고 실행하는데 필요한 모든 것을 설치하기 위해 Raspberry Pi에서 실행할 수있는 편리한 부트스트랩 스크립트를 가지고 있습니다.
 
 - - -
 
 # TJBot 소프트웨어 설치하기
 
 1. 귀하의 Raspberry Pi 터미널을 엽니다.
 
 모니터와 키보드를 파이에 연결 한 경우, 메뉴 바에서 터미널 아이콘 (! [Terminal](terminal.png))을 클릭하십시오. SSH를 설정했다면, SSH로 Raspberry Pi를 만들 수 있습니다.
 
 2. 터미널에 다음 명령을 입력하고 return 키를 누릅니다.
 
 `curl -sL http://ibm.biz/tjbot-bootstrap | sudo sh -`
 
 이 스크립트는 Raspberry Pi를 구성하는 방법에 대해 일련의 질문을합니다. 질문을 이해할 수 없으면 기본값을 사용해도됩니다.
 
 * 중요 :
 스크립트에서 묻는 첫 번째 질문은 TJBot의 이름을 지정하는 것입니다. 선택한 이름은 Raspberry Pi의 호스트 이름으로 사용됩니다. 이것이 귀하의 네트워크에서 라즈베리 파이를 찾는 방법입니다. 예를 들어, TJBot의 이름을 "tinker"라고하면 로컬 네트워크에서 "tinker.local"및 "tinker"라는 Bluetooth 장치로 Raspberry Pi에 액세스 할 수 있습니다. TJBot에 붙인 이름을 기록해 두십시오 - 다음 장에서 필요할 것입니다.
 
 부트스트랩 스크립트가 실행 된 후 데스크탑 (또는 지정한 위치)에 "tjbot"폴더가 있습니다. 테스트를 실행하여 TJBot의 하드웨어가 작동하는지 확인하려면 bootstrap 폴더에서`runTests.sh` 스크립트를 실행할 수 있습니다.
 `cd ~/Desktop/tjbot/bootstrap && ./runTests.sh`
 
 - - -
 
 # TJBot daemon 소프트웨어 설치하기
 
 TJBot 데몬은 TJBot이 BLE(Bluetooth Low Energy)를 통해 명령을 수신 할 수 있게합니다.
 
 1. 터미널에서 다음 명령을 실행하여 TJBot 데몬을 설치하십시오.
 
 `curl -sL http://ibm.biz/tjbot-daemon | sh -`
 
 * Callout(😈 "daemon"은 무엇인가?):
 1.  데몬은 사용자의 직접 통제하에 있지 않고 백그라운드 프로세스로 실행되는 컴퓨터 프로그램입니다. TJBot 데몬은 TjBot의 백그라운드에서 실행되어 iPad에서 명령을 수신합니다.

 2.  [IBM Bluemix](https://bluemix.net) IBM 계정에 접속해서 Assistant, Language Translator, Speech to Text, Text to Speech, 톤 분석기 및 시각 인식과 같은 Watson 서비스의 인스턴스를 생성하고 작성하십시오.
 
 3. 각 서비스의 인증 자격 증명을 tjbot-daemon 폴더의`config.js` 파일에 복사하십시오. 이 폴더의 기본 위치는 바탕 화면에 있습니다.

 
 * Callout(🤖 TJBot과 Watson):
 TJBot은 생명을 얻기 위해 많은 [Watson services](https://www.ibm.com/watson/products-services/)를 사용합니다. 각 서비스에는 인증 자격 증명이 필요합니다. 이는 이곳에서 얻을 수 있습니다. [IBM Bluemix](https://bluemix.net). TJBot 부트스트랩 스크립트는 Bluemix 계정을 만드는 방법, TJBot에 필요한 Watson 서비스 인스턴스를 작성하는 방법 및 각 서비스에 대한 인증 자격 증명을 얻는 방법에 대한 지침을 제공합니다. 이러한 인증 자격 증명은 TJBot 데몬에 필요하며 지금의 Playgrounds가 아닌`tjbot-daemon / config.js` 파일에 TJBot에 저장됩니다.

 
 테스트에 문제가 생겨서 무엇이 잘못되었는지 알 수 없다면, [open an issue on GitHub](https://github.com/ibmtjbot/tjbot/issues) 우리는 당신을 돕기 위해 최선을 다할 것입니다!

 
 - - -
 
 [Next chapter: TJBot Explores the World](@next)
 */
//#-code-completion(everything, hide)

