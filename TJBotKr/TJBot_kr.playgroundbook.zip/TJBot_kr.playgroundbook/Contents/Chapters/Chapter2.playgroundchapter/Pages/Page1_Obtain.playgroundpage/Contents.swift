//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

//#-end-hidden-code
/*:
 Tinker는 실제 TJBot으로 변신 할 준비가되었습니다!
 
 물리적인 TJBot을 얻는 몇 가지 방법이 있습니다. 이러한 모든 옵션에 대한 자세한 내용은
 [TJBot web site](http://ibm.biz/mytjbot).에서 확인할 수 있습니다.
 
 # TJBot 몸통을 위해 3D 프린터 활용하기
 
 ![3D Printed TJBot](3dprint.png) ![]()
 
 TJBot의 3D 인쇄 지침은
[Instructables](http://www.instructables.com/id/Build-TJ-Bot-Out-of-Cardboard).에서 찾을 수 있습니다.
 
 # TJBot 몸통을 위해 Laser cut 활용하기
 
 ![Laser cut TJBot](lasercut.png) ![]()
 
 TJBot 레이저 커팅 지침은
 [Instructables](http://www.instructables.com/id/Build-TJ-Bot-Out-of-Cardboard/). 에서 찾을 수 있습니다.
 
 # TJBot kit 구매하기
 
 TJBot kit를 온라인으로 판매하는 수많은 업체가 있습니다. 이들은
 [TJBot website](http://ibm.biz/mytjbot).입니다.
 
 # 전기제품 ⚡️
 
 자신만의 3D 인쇄물 또는 레이저 커팅을 통해 TJBot을 제작하는 경우, 그에게 생명을 불어 넣을 수있는 수 많은 전자 부품이 있습니다. 이것들에 대한 목록을 찾을 수 있습니다.
 [TJBot's GitHub page](http://github.com/ibmtjbot/tjbot).
  
 * Callout(단어를 널리 알리세요!):
 #tjbot 해시 태그로 TJBot을 구축 한 경험을 공유하십시오.
 
 TJBot에 필요한 모든 부품을 확보하고 나면 다음 단계는 조립입니다!

 - - - 
 
 [Next step: Assemble TJBot](@next)
 */
//#-code-completion(everything, hide)
