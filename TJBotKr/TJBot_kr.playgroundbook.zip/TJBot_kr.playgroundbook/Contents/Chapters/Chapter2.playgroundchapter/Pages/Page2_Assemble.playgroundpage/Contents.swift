//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

//#-end-hidden-code
/*:
 # TJBot 조립하기
 
 TJBot을 조립하는 방법에 대한 단계별 지침은 온라인상의 다음 안내서에서 찾을 수 있습니다.
 
 - [Assembling a 3D printed TJBot](http://www.instructables.com/id/Build-a-3D-Printed-TJBot/)
 
 - [Assembling a laser cut TJBot](http://www.instructables.com/id/Build-TJ-Bot-Out-of-Cardboard/)
 
 레이저 커팅 판지를 TJBot으로 접는 방법을 보십시오.
 ![Assembly Video](assembly.mp4)
 
 * 중요:
 TJBot을 조립할 때 서보 모터를 설치할 때 주의하십시오. 서보 모터가있는 경우에는 TJBot의 몸체 밑 부분을 다리에 붙이고 * 첫 번째 내부 레이어를 추가하기 전에 * 삽입해야합니다. 서보를 부착하는 방법에 대한 구체적인 설명은 아래의 서보 모터 섹션을 참조하십시오.

 - - - 
 
 # 전자 장치 배선
 
 아래 다이어그램은 서로 다른 하드웨어 구성 요소가 TJBot의 본체에 장착되어 있고 Raspberry Pi에 연결하는 방법을 보여줍니다.
 
 ![image](wiring.png)
 
 * Callout(💡Tip):
 여러분의 Raspberry Pi를 위한 핀번호 인터렉티브 다이어그램을 확인하세요. [Pinout.xyz](http://pinout.xyz)
 
 ## LED 연결
 
 LED는 최상위 내부 층의 작은 구멍에 장착됩니다. 평평한면이 오른쪽을 향하도록 LED를 삽입하십시오. LED를 삽입 한 후 개별 핀을 펼치면 암컷에서 암컷으로 점퍼 선을 쉽게 부착 할 수 있습니다. 점퍼 선을 두 번째 내부 레이어의 작은 원형 구멍으로 통과시켜 Raspberry Pi로 가져옵니다.
 
 - LED의 가장 왼쪽 핀은 데이터 핀이며 Raspberry Pi의 PIN 12 (BCM 18)에 연결됩니다.
 - 왼쪽에서 두 번째 핀은 전원 (+ 3.3V) 용이며 핀 1에 연결됩니다.
 - 왼쪽에서 세 번째 핀은 접지 용이며 라즈베리 파이의 접지 핀에 연결할 수 있습니다. PIN 6을 권장합니다.
 - 가장 오른쪽 핀은 사용되지 않습니다.
 
 * 중요 :
 LED를 연결할 때주의하십시오! 잘못된 방향으로 연결되면 화상을 입을 수 있습니다. LED에는 한쪽면에 평평한 노치가있어 배선 다이어그램으로 방향을 지정할 때 사용할 수 있습니다.
 
 ## 서보 설치하기
 
 서보가 TJBot의 몸 안쪽에 있습니다. 다리가 바닥에 부착 된 후, 그리고 첫 번째 내부 레이어가 아래로 늘어지기 전에 삽입해야합니다. 전선이 TJBot의 몸체에 가장 가깝도록 서보를 삽입하십시오. 그런 다음 첫 번째 내부 레이어를 아래로 내리고 서보를 제자리에 잠급니다.
 
 - 갈색 와이어는 지면 용이므로 라즈베리 파이의 접지 핀에 연결할 수 있습니다. PIN 14을 권장합니다.
 - 빨간색 (가운데) 전선은 전원 (+ 5V) 용이며 PIN 2에 연결됩니다.
 - 주황색 선은 데이터 핀이며 PIN 26 (BCM 7)에 연결됩니다.

 
 * Callout(💡 Tip):
 서스펜션 와이어를 라즈베리 파이에 쉽게 연결하기 위해 암컷에서 수컷으로 점퍼 선을 사용하세요. 단, 다른 색상에주의하십시오!

 ## 카메라 설치하기
 
 카메라는 TJBot의 눈 뒤에있는 장착 브래킷에 앉습니다. 카메라를 연결하려면 장착 레일을 장착 구멍에 삽입하십시오. 그런 다음 리본 케이블이 카메라에 연결되어 있는지 확인하고 리본 케이블을 본체의 슬릿을 통해 밀어 라즈베리 파이의 카메라 커넥터쪽으로 당깁니다. 그런 다음 마운팅 레일 사이에 카메라를 밀어 넣고 나머지 카메라 마운트 부품과 함께 제자리에 고정시킵니다. 마지막으로 리본 케이블을 Raspberry Pi에 연결하여 리본의 금속 접점이 위쪽을 향하게합니다.

 
 * Callout(💡Tip):
 카메라의 올바른 방향은 리본 케이블 커넥터가 아래를 향하게하는 것입니다. 그러나 일부 3D 인쇄 된 봇에서는 카메라 장착 브래킷이 카메라 보드에 장착 된 전자 부품으로 인해 조립이 어려울 수 있습니다. 이 경우 리본 케이블 커넥터가 위쪽을 향하도록 카메라 방향을 반대로 할 수 있습니다. 이렇게하면 tjbot-daemon 설정에서`tj.configuration.see.camera.verticalFlip`을`true`로 설정하여 방향을 고정시킬 수 있습니다.

 
 - - -
 
 [Next step: Install TJBot's software](@next)
 */
//#-code-completion(everything, hide)
