//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

import PlaygroundSupport
import UIKit

PlaygroundPage.current.assessmentStatus = .pass(message: nil)
//#-end-hidden-code
/*:
 * Callout(🤖 TJBot 하드웨어):
 이 연습을 끝내려면 TJBot에 연사가 있는지 확인하십시오.
 
 당신의 TJBot은 이제 말할 수있는 능력을 가졌습니다! [Watson Text to Speech] (https://www.ibm.com/watson/developercloud/text-to-speech.html) 서비스를 사용하면 TJBot이 자신의 목소리로 표현할 수 있습니다.
 
 ** 목표 ** : TJBot에게 자신의 인생 이야기의 내용을 소리내어 알려주도록 하십시오. `generateLifeStory()`메소드를 사용하여 TJBot의 라이프 스토리를 생성하고,`tj.speak()`메소드를 사용하여 TJBot이 말하게 하세요.

 */
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, page, proxy)
//#-code-completion(identifier, show, tj, ., speak(_:), generateLifeStory())
let tj = PhysicalTJBot()

let lifeStory = [
    "yourName": /*#-editable-code*/""/*#-end-editable-code*/,
    "favoriteCity": /*#-editable-code*/""/*#-end-editable-code*/,
    "favoriteFood": /*#-editable-code*/""/*#-end-editable-code*/,
    "favoriteExercise": /*#-editable-code*/""/*#-end-editable-code*/,
    "favoriteColor": /*#-editable-code*/""/*#-end-editable-code*/,
    "favoriteBand": /*#-editable-code*/""/*#-end-editable-code*/
]
//#-hidden-code
func generateLifeStory() -> String {
    func value(from dictValue: String?, defaultingTo defaultValue: String) -> String {
        if let value = dictValue, !value.isEmpty {
            return value
        } else {
            return defaultValue
        }
    }
    
    let name = value(from: lifeStory["yourName"], defaultingTo: "human")
    let city = value(from: lifeStory["favoriteCity"], defaultingTo: "on Mars")
    let food = value(from: lifeStory["favoriteFood"], defaultingTo: "sushi")
    let exercise = value(from: lifeStory["favoriteExercise"], defaultingTo: "jumping jacks")
    let color = value(from: lifeStory["favoriteColor"], defaultingTo: "red")
    let band = value(from: lifeStory["favoriteBand"], defaultingTo: "the grateful dead")
    
    return "Hello \(name)!  My name is \(tj.configuration.name). It's nice to meet you! I was designed with love by IBM researchers in New York, but if I could live anywhere it would be \(city). I can't eat anything, but if I did, I'd eat \(food) every single day. My legs don't work yet but if I could exercise, I would do \(exercise) all the time. If I had any money, I would buy a \(color) car and drive down the highway listening to \(band) on the radio."
}
//#-end-hidden-code
//#-editable-code
//#-end-editable-code

//: [Next page: Listen and Act](@next)
