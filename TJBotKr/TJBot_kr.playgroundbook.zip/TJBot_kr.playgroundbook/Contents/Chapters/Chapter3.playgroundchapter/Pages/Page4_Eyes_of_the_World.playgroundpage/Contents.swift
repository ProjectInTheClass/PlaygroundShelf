//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

import PlaygroundSupport
import UIKit

PlaygroundPage.current.assessmentStatus = .pass(message: nil)
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
/*:
 * Callout(🤖 TJBot 하드웨어):
 이 연습을 완료하려면 TJBot에 마이크, 카메라 및 스피커가 있는지 확인하십시오.
 
 TJBot의 왼쪽 눈 뒤에는 실제 세계의 물건을 볼 수있는 카메라가 있습니다. [Watson Visual Recognition] (https://www.ibm.com/watson/developercloud/visual-recognition.html) 서비스를 사용하여 TJBot은 자신이 보는 것을 해석하고 이해할 수 있습니다.
 
 `tj.see()`메소드는 TJBot이 볼 수 있게 합니다. 그것은 TJBot에게 사진을 찍고 그것을 Watson과 해석하도록 알려줍니다. `VisionResponse`를 반환하는데, TJBot이 인식 한 객체 목록과 각 객체를 정확하게 식별했는지 여부를 나타내는 점수를 반환합니다. 신뢰 수준은 [0.0, 1.0]의 범위에 있으며, 1.0이 가장 높은 신뢰도입니다.
 
 ** 목표 ** :`tj.listen(_ :)`,`tj.see()`,`tj.speak(_ :)` 메소드를 사용하여 당신이 보는 것을 알려주는 TJBot을위한 프로그램을 생성하십시오.
 
 1. 연설 메시지를 듣고 TJBot은 당신이 그와 이야기하고 있다는 것을 압니다. 코드에서 몇 가지 예제 프롬프트를 정의했습니다. `tj.see()`를 호출하기 전에`tj.listen(_ :)`에 의해 반환 된 메시지가 프롬프트를 포함하고 있는지 확인하십시오. `tj.listen(_ :)`에 의해 리턴 된 메시지는 모두 소문자이며 구두점을 포함하지 않는다!
 
 2. TJBot이 자신이보고있는 것에 대해 생각하고 있다고 발표합니다. 예를 들어, TJBot은 "저에 대해 생각하게하십시오" 라고 말할 수 있습니다.
 
 3.`tj.see()`를 사용하여 TJBot이 무엇을보고 있는지 결정하십시오.
 
 * Callout (⚠️주의) :
 Watson이 오류를 반환하는 경우를 대비하여`VisionResponse`에`error` 속성을 확인하십시오!
 
 4.`tj.speak()`를 사용하여 TJBot이 자신이 보고있는 것을 말하게하십시오. 예를 들어, TJBot은 "나는 의자, 사람, 컴퓨터를보고 있습니다."라고 말할 수 있습니다. TJBot이 발표하기 전에 보고있는 것에 자신감이 있는지 확인하기 위해 각 객체의 'confidence'값을 확인할 수 있습니다!
 
 * 실험 :
 `tj.read ()`를 사용하여 TJBot이 텍스트를 읽도록하십시오.
 */
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, page, proxy)
//#-code-completion(identifier, show, tj, ., shine(color:), pulse(color:duration:), sleep(duration:), raiseArm(), lowerArm(), wave(), speak(_:), listen(_:), see(), read(), contains(_:), lowercased(), description, VisionResponse, error, objects, VisualObjectIdentification, name, confidence, highestConfidenceObject)
//#-code-completion(literal, show, color)
let tj = PhysicalTJBot()

//#-editable-code
let prompts = [
    "what are you looking at",
    "what are you seeing",
    "what do you see",
    "what can you see"
]

//#-end-editable-code

//: [Next page: Rock, Paper, TJBot! (Part I)](@next)
