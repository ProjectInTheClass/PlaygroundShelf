//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

import PlaygroundSupport
import UIKit

PlaygroundPage.current.assessmentStatus = .pass(message: nil)
//#-end-hidden-code
/*:
 * Callout(🤖 TJBot 하드웨어):
 이 연습을 완료하려면 TJBot에 LED, 스피커 및 서보가 있는지 확인하십시오.
 
 TJBot이 게임을 좋아한다는 것을 알고 있습니까? Rock Paper Scissors를 즐기기를 좋아합니다.
 
 **목표** : 가위 바위 가위 게임을하기 위해 TJBot을 프로그래밍하십시오!
 
 * Callout (바위 종이 가위의 규칙) :
 가위, 바위, 보는 쉬운 게임입니다. 선수는 두 명, 당신과 TJBot. 셋을 세고 두 선수는 바위, 종이, 또는 가위를 선택하고 서로 공개합니다. 우승자는 다음 규칙을 기반으로 합니다 : 바위는 가위를, 종이는 바위를, 가위는 종이를 자릅니다. 단순합니다!
 
 이 연습에서는 TJBot이 다음 작업을 수행해야 합니다.
 1. Rock Paper Scissors의 새로운 게임이 곧 시작될 것이라고 발표하십시오.
 2. 가위 바위 가위의 규칙을 설명하십시오.
 3. 팔을 흔들면서 셋을 카운트 다운하십시오.
 4. 당신의 움직임을 발표하십시오. 예를 들어, TJBot은 "당신이 가위를 선택했습니다."라고 말할 수 있습니다.
 5. 팔을 내리고 그의 움직임을 발표하십시오. 예를 들어, TJBot은 "나는 바위를 선택했다"고 말할 것입니다.
 6. 승자를 결정하십시오. 이기면 TJBot이 당신을 축하해 줘야합니다! TJBot이 이기면 승리 춤을 추어야 합니다. 동점 일 경우 TJBot은 다시 게임을 해야합니다.
 
 * Callout (💡 팁) :
 시작하는 데 도움이되는 몇 가지 코드를 작성했습니다.  `Move` 는 유효한 모든 가위 바위 가위를 정의하는 열거형입니다. `randomMove()`메소드는 무작위`Move`를 반환합니다. `gameResult(tjbot : beats :)`메쏘드는 TJBot의 움직임이 당신의 움직임보다 우세한지를 결정합니다. 이 실습에서는 변수 myMove에서 자신의 이동을 지정합니다.

 
 */
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, page, proxy)
//#-code-completion(identifier, show, tj, ., shine(color:), pulse(color:duration:), raiseArm(), lowerArm(), wave(), sleep(duration:), speak(_:), arc4random_uniform(_:), UInt32, Int)
//#-code-completion(literal, show, color)
let tj = PhysicalTJBot()

//#-copy-source(id1)
//#-editable-code
enum Move: String {
    case rock
    case paper
    case scissors
}

enum GameResult: String {
    case win
    case tie
    case lose
}

func randomMove() -> Move {
    let randomNumber = Int(arc4random_uniform(UInt32(3)))
    switch randomNumber {
    case 0:
        return .rock
    case 1:
        return .paper
    case 2:
        return .scissors
    default:
        return .rock
    }
}

func gameResult(tjbot move: Move, beats other: Move) -> GameResult {
    switch move {
    case .rock:
        switch other {
        case .rock: return .tie
        case .paper: return .lose
        case .scissors: return .win
        }
    case .paper:
        switch other {
        case .rock: return .win
        case .paper: return .tie
        case .scissors: return .lose
        }
    case .scissors:
        switch other {
        case .rock: return .lose
        case .paper: return .win
        case .scissors: return .tie
        }
    }
}

let intro = "Hello! Let's play a game of rock paper scissors. The rules are as follows. Rock breaks scissors, scissors cuts paper, and paper covers rock. Ready? Let's go."

let tjbotMove: Move = randomMove()
let myMove: Move = .rock

//#-end-editable-code
//#-end-copy-source

//: [Next page: Rock, Paper, TJBot! (Part II)](@next)
