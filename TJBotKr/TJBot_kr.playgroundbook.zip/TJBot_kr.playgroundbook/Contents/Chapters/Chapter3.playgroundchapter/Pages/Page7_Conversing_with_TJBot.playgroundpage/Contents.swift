//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

import PlaygroundSupport
import UIKit

PlaygroundPage.current.assessmentStatus = .pass(message: nil)
PlaygroundPage.current.needsIndefiniteExecution = true
//#-end-hidden-code
/*:
 * Callout(🤖 TJBot Hardware):
 이 연습을 완료하려면 TJBot에 마이크와 스피커가 있는지 확인하십시오.
 
 TJBot을 챗봇으로 바꿀 수 있다는 것을 알고 있습니까? TJBot은 [Watson Assistant](https://www.ibm.com/cloud/watson-assistant/) 서비스를 사용하여 다방면으로 대화 할 수 있습니다.
 
 * Callout (⚠️ 선행 조건) :
 과제를 수행하려면 [Watson Assistant 도구](https://www.ibmwatsonconversation.com/login)에서 대화의 흐름을 정의해야합니다.  방법에 대한 단계별 지침은 [Instructable](http://www.instructables.com/id/Build-a-Talking-Robot-With-Watson-and-Raspberry-Pi/)에서 찾을 수 있습니다. ) (단계 6). [Watson Assistant 도구](https://www.ibmwatsonconversation.com/login) 도구에 로그인하여 대화 플로우를 작성하고 작업 공간 ID를 기록하십시오. Watson Assistant 도구를 사용하려면 [Bluemix](http://bluemix.net) 계정이 필요합니다.
 
 **목표** :`tj.converse(workspaceId : message :)`,`tj.listen(_ :)`및`tj.speak(_ :)`메소드를 사용하여 TJBot과의 대화에 참여하십시오.
 
 * Callout (💡 팁) :
 컴퓨터 근처에있는 경우 샘플 TJBot 대화 흐름을 Watson Assistant 도구로 가져올 수 있습니다. TJBot의 [GitHub 저장소](https://github.com/ibmtjbot/tjbot)에서 [Conversation recipe](https://github.com/ibmtjbot/tjbot/tree/master/recipes/conversation)를 확인하십시오. 시작하기 위해 사용할 수있는 샘플 대화 파일이 있습니다.
 
 `tj.converse(workspaceId : message :)`메소드는`ConversationResponse` 객체를 반환합니다. 이 객체는 TJBot이 말해야하는`text` 응답을 포함합니다.
 
 * Callout (⚠️주의) :
 Watson이 오류를 반환하는 경우를 대비하여`ConversationResponse`에서`error` 속성을 확인하십시오!
 
 
 */
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, page, proxy)
//#-code-completion(identifier, show, tj, ., shine(color:), pulse(color:duration:), raiseArm(), lowerArm(), wave(), sleep(duration:), speak(_:), listen(_:), see(), read(), converse(workspaceId:message:), description, ConversationResponse, error, text)
//#-code-completion(literal, show, color)
let tj = PhysicalTJBot()

let workspaceId = /*#-editable-code*/""/*#-end-editable-code*/

//#-editable-code
//#-end-editable-code

//: [Next page: TJBot's Adventures with You](@next)
