//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

import PlaygroundSupport
import UIKit

PlaygroundPage.current.assessmentStatus = .pass(message: nil)
//#-end-hidden-code
/*:
 Tinker는 실제 TJBot으로 변신했습니다!
 
 이제 Tinker는 새로운 세상에 도착했습니다. Tinker는 연결하는 방법을 보여주고 싶습니다.
 
 ** 목표 ** : TJBot에 연결하십시오.
 
 1. "Connect TJBot"을 누르고 목록에서 TJBot을 선택하십시오.
 
 2. "내 코드 실행"을 눌러 TJBot을 빛나게하십시오!
 
 * 실험 : TJBot의 색, 펄스 횟수 및 각 펄스의 지속 시간을 변경하십시오.
 */
//#-hidden-code
extension Array {
    var randomElement: Element {
        let randomIndex = Int(arc4random_uniform(UInt32(self.count)))
        return self[randomIndex]
    }
}
//#-end-hidden-code
let tj = PhysicalTJBot()

let colors = [/*#-editable-code*/#colorLiteral(red: 1, green: 0.1492801309, blue: 0, alpha: 1), #colorLiteral(red: 0, green: 0.9768045545, blue: 0, alpha: 1), #colorLiteral(red: 0.01680417731, green: 0.1983509958, blue: 1, alpha: 1), #colorLiteral(red: 1, green: 0.9439396262, blue: 0.00457396172, alpha: 1), #colorLiteral(red: 0, green: 0.991381228, blue: 0.9948161244, alpha: 1), #colorLiteral(red: 1, green: 0.6262393594, blue: 0.1212334707, alpha: 1), #colorLiteral(red: 0.5819275379, green: 0.3353917003, blue: 0.8818522096, alpha: 1), #colorLiteral(red: 0.9981537461, green: 0, blue: 0.9764257073, alpha: 1)/*#-end-editable-code*/]

for _ in 0 ..< /*#-editable-code*/6/*#-end-editable-code*/ {
    tj.pulse(color: colors.randomElement, duration: /*#-editable-code*/0.5/*#-end-editable-code*/)
}

/*:
 TJBot가 LED가 빛나지 않으면 tjbot-daemon 프로세스가 TJBot에서 실행 중인지 확인하십시오. 문제가 계속되면 아래로 문의하세요.
 [opening an issue on GitHub](https://github.com/ibmtjbot/tjbot/issues).
 
 이제는 TJBot에 연결하는 방법을 알았으므로 자신이 할 수있는 일을 탐구 해봅시다!
 */

//: [Next page: TJBot Tells His Story](@next)
