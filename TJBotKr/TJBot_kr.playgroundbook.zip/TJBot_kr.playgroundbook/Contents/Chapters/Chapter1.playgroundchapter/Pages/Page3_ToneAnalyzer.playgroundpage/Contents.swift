//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

import PlaygroundSupport
import UIKit

//#-end-hidden-code
/*:
 Rebus는 그녀가 여행하는 동안 목격 한 모든 놀라운 것들에 대해 Tinker에게 말하기 시작합니다. 그녀의 이야기는 Tinker를 감정의 롤러 코스터로 데려 갑니다.
 
 **목표**: Tinker가 Rebus의 이야기를 통해 얻은 감동적인 콘텐츠를 [Watson Tone Analyzer](https://www.ibm.com/watson/developercloud/tone-analyzer.html) 서비스를 사용하여 이해할 수 있도록 도와 주세요.
 
 1.  [Watson Tone Analyzer](https://console.bluemix.net/catalog/services/tone-analyzer) 페이지를 열고 서비스 인스턴스를 만들기 위해서 오른쪽 하단의 "Create" 버튼을 탭하세요. 무료 Bluemix 계정을 가지고 있지 않다면 무료 Bluemix 계정을 만드십시오.

 2. 왼쪽 사이드 바에서 '관리'를 탭한 다음 '자격증 명 표시'를 탭합니다.
 
 ![Tone Analyzer Credentials](tone-analyzer-credentials.png)
 
 3. 아래의 'apikey'자격증 명을 입력하십시오. 이 자격 증명은 추후 연습을 위해 저장되며 자격 증명을 변경해야하는 경우 이 페이지를 다시 실행해야합니다.
 */
Watson.toneAnalyzer.apikey =
    /*#-editable-code*/""/*#-end-editable-code*/
/*:
 4. `tinker.analyzeTone()`메소드를 사용하여 문장의 톤을 분석하십시오. 각 문장마다 `rebus.speak(: _)`을 사용하여 문장을 말하십시오. 또한, 아래의 색상 가이드를 사용하여 지배적인 감정을 기반으로 LED를 비추세요.
 
 ![TJBot emotions](tjbot-emotions.png)
 
 - - -
 * Callout(💡 Tip):
 `tinker.analyzeTone()`은 Watson이 수행 한 톤 분석의 다양한 차원, 감정적인 내용, 언어 스타일, 사회적 경향을 포함하는`ToneResponse`를 반환합니다. `emotion` 차원을 사용하여 주어진 문장에 기쁨, 분노, 공포, 슬픔의 감정이 포함되어있는 정도를 결정하십시오 (1.0은 가장 높은 수준 임). `ToneResponse`를 검사하고 지배적인 `감정'(예 : 가장 가치가 높은 감정)을 반환하는 helper 함수를 만드는 것이 도움이 될 수 있습니다.
 
 - - -
 * Callout(⚠️ Caution):
 Watson이 오류를 반환 한 경우를 대비해서`ToneResponse`의`error` 속성을 확인하십시오!
 
 */
let tinker = VirtualTJBot()
let rebus = RebusTheBee()

enum Emotion: String {
    case anger
    case fear
    case joy
    case sadness
    case unknown
}

//#-hidden-code
let page = PlaygroundPage.current
let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy
tinker.assessorDelegate = TaskAssessorDelegate(success: successMessage, hints: nil, successBeeCommand: successBeeCommand, successTJBotInternalCommand: successBotCommand, pageName: pageName)
proxy?.delegate = tinker
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, page, proxy)
//#-code-completion(identifier, show, tinker, ., rebus, shine(color:), pulse(color:duration:), sleep(msec:), raiseArm(), lowerArm(), wave(), analyzeTone(text:), speak(_:), sorted(), description, ToneResponse, error, emotion, language, social, anger, fear, joy, sadness, analytical, confident, tentative, openness, conscientiousness, extraversion, agreeableness, emotionalRange)
//#-code-completion(literal, show, color)
//#-code-completion(keyword, show, for)
let story: [String] = [

    "There's fire in my heart for you!", // joy
    "I saw smoke rising in the middle of the apartment complex.", // sadness
    /*#-editable-code*/""/*#-end-editable-code*/
]

func getPrimaryEmotion(from toneResponse:ToneResponse) -> Emotion {
    if (toneResponse.error != nil) {
        return .unknown
    }
    
    let dict: [Emotion: Double] = [
        .anger: toneResponse.emotion.anger,
        .fear: toneResponse.emotion.fear,
        .joy: toneResponse.emotion.joy,
        .sadness: toneResponse.emotion.sadness
    ]
    let sortedEmotions = Array(dict).sorted {$0.1 > $1.1}
    guard let first = sortedEmotions.first else {
        return .unknown
    }
    return first.key
}

for sentence in story {
    let response = tinker.analyzeTone(text: sentence)
    let emotion = getPrimaryEmotion(from: response)
    
    rebus.speak(sentence)
    
    switch emotion {
    case .unknown :
        tinker.wave()
    case .anger:
        tinker.shine(color: UIColor.red)
    case .fear:
        tinker.shine(color: UIColor.purple)
    case .joy:
        tinker.shine(color: UIColor.yellow)
    case .sadness:
        tinker.shine(color: UIColor.blue)
    }
}



