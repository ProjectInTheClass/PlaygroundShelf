//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

import PlaygroundSupport
import UIKit

//#-end-hidden-code
/*:
 Rebus의 메시지를 번역 한 후 Tinker는 실제 살아 있는 TJBot으로 변환하는 데 필요한 단계를 배웠습니다.
 
 **Goal**: TJBot의 춤추게 하세요. 🤖🕺
 
 1. 첫째, 당신은 붉은 빛을 내야합니다.
 2. 다음으로 팔을 두 번 흔듭니다.
 3. 밝은 노란색 빛을 만드십시오.
 4. 팔을 내려 놓으십시오.
 5. 푸른 빛을 내고 팔을 들어 올리십시오.

 
 */
let tinker = VirtualTJBot()

//#-hidden-code
let page = PlaygroundPage.current
let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy
tinker.assessorDelegate = TaskAssessorDelegate(success: successMessage, hints: nil, successBeeCommand: successBeeCommand, successTJBotInternalCommand: successBotCommand)
proxy?.delegate = tinker
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, page, proxy)
//#-code-completion(identifier, show, tinker, ., shine(color:), pulse(color:duration:), sleep(duration:), raiseArm(), lowerArm(), wave())
//#-code-completion(literal, show, color)
//#-editable-code
//#-end-editable-code
