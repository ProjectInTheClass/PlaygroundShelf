//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

import PlaygroundSupport
import UIKit

//#-end-hidden-code
/*:
팅커는 매우 어두운 화면에서 외롭습니다. 다행히도, Tinker는 머리 위에 LED 조명을 가지고 있습니다!

 **목표**: Tinker가 `tinker.shine(color :)` 메소드를 사용하여 빛을 비추어 주위를 비추도록 도와주세요.
 
 * 실험:
 Tinker의 다른 LED method인 `tinker.pulse(color : duration :)`를 시도해보십시오. 이 방법은 설정된 시간 (초) 동안 LED를 깜빡입니다. Tinker는 빛나는 것 또는 깜빡이는것 사이에 멈추는 구간을 추가하고자 할 때를 대비하여 `tinker.sleep(duration :)`을 사용하여 잠들게 할 수 있습니다.
 
 
 */
let tinker = VirtualTJBot()

//#-hidden-code
let page = PlaygroundPage.current
let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy
tinker.assessorDelegate = TaskAssessorDelegate(success: successMessage, hints: nil, successBeeCommand: successBeeCommand, successTJBotInternalCommand: successBotCommand)
proxy?.delegate = tinker

//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, page, proxy)
//#-code-completion(identifier, show, tinker, ., shine(color:), pulse(color:duration:), sleep(duration:))
//#-code-completion(literal, show, color)
//#-end-hidden-code
//#-editable-code
//#-end-editable-code
