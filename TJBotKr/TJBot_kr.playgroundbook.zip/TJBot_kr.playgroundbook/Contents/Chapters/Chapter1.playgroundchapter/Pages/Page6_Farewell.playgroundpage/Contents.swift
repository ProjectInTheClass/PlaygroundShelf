//#-hidden-code
/*
 Copyright (C) 2017 IBM. All Rights Reserved.
 See LICENSE.txt for this book's licensing information.
 */

import PlaygroundSupport
import UIKit

//#-end-hidden-code
/*:
 Tinker가 현실 세계에서 모험을 시작하기 전에 Tinker는 Rebus와 함께 감사의 말을 전하고 싶어합니다.

 
 **목표**: Rebus에게 작별 인사를 하기 위해 배웠던 명령어를 창의적이고 독창적인 방식으로 조합해서 사용하세요.

 
 * 실험:
 이 페이지에서는 사용 가능한 모든 명령을 사용하여 Tinker 및 Rebus를 가지고 놀 수 있습니다. 자동 완성을 사용하여 수행 할 수있는 모든 작업을 확인하십시오. 예를 들어, 톤 분석기가 반환한 언어와 사회적 차원을 탐색하거나 다른 언어로 번역 할 수 있는지 알아보십시오. 창조적으로 생각하고 재미있게 즐기세요!
 
 */
//#-code-completion(everything, hide)
//#-code-completion(currentmodule, show)
//#-code-completion(identifier, hide, page, proxy)
//#-code-completion(identifier, show, tinker, ., rebus, shine(color:), pulse(color:duration:), sleep(duration:), raiseArm(), lowerArm(), wave(), analyzeTone(text:), speak(_:), identifyLanguage(text:), translate(text:sourceLanguage:targetLanguage:), sorted(), description, ToneResponse, error, emotion, language, social, anger, fear, joy, sadness, analytical, confident, tentative, openness, conscientiousness, extraversion, agreeableness, emotionalRange, TJTranslationLanguage, unknown, arabic, chinese, german, english, french, italian, japanese, korean, spanish, portuguese, languageName, LanguageIdentification, language, confidence)
//#-code-completion(literal, show, color)
let tinker = VirtualTJBot()

//#-hidden-code
let page = PlaygroundPage.current
let proxy = page.liveView as? PlaygroundRemoteLiveViewProxy
proxy?.delegate = tinker
//#-end-hidden-code
//#-editable-code
//#-end-editable-code

//: [Next chapter: Building TJBot](@next)
